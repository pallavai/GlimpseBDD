﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BDDWithSpecFlow.ProjectCalc
{
    class Calculator
    {
        public int FirstNumber { get; set; }
        public int SecondNumber { get; set; }

        public int Add()
        {
            return FirstNumber + SecondNumber;
        }
        public int Subtract()
        {
            return FirstNumber - SecondNumber;
        }

       public int Multiply()
        {
            return FirstNumber * SecondNumber;
        }

        /*public int Divide()
        {
            return FirstNumber / SecondNumber;
        }
       */
    }
}
