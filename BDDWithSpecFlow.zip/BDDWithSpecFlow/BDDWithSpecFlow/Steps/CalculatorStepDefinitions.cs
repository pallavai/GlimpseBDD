﻿using NUnit.Framework;
using System;
using TechTalk.SpecFlow;

namespace BDDWithSpecFlow.Steps
{
    [Binding]
    public sealed class CalculatorStepDefinitions
    {
        private ProjectCalc.Calculator calculator = new ProjectCalc.Calculator();

        private readonly ScenarioContext _scenarioContext;
        private int result;

        public CalculatorStepDefinitions(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }

        [BeforeScenario()]
        public void BeforeScenario()
        {
            Console.WriteLine("Starting " + _scenarioContext.ScenarioInfo.Title);
            Console.WriteLine("Starting " + _scenarioContext.ScenarioInfo.Tags.ToString());
        }

        [AfterScenario()]
        public void AfterScenario()
        {
            Console.WriteLine("Starting " + _scenarioContext.ScenarioInfo.Description);
            
        }

        [Given("the first number is (.*)")]
        public void GivenTheFirstNumberIs(int number)
        {
            calculator.FirstNumber = number;
        }

        [Given("the second number is (.*)")]
        public void GivenTheSecondNumberIs(int number)
        {
            calculator.SecondNumber = number;
        }

        [When("the two numbers are added")]
        public void WhenTheTwoNumbersAreAdded()
        {
            result = calculator.Add();
        }

        [When(@"the two numbers are subtracted")]
        public void WhenTheTwoNumbersAreSubtracted()
        {
            result = calculator.Subtract();
        }


        [When(@"the two numbers are multiplied")]
        public void WhenTheTwoNumbersAreMultiplied()
        {
            result = calculator.Multiply();
        }


        [Then("the result should be (.*)")]
        public void ThenTheResultShouldBe(int expresult)
        {
            Assert.AreEqual(expresult, result);
        }
    }
}


